export interface UserApi {
  id: number;
  fullName: string;
  email: string;
  role: string;
  createdAt: string;
}