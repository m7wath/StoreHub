﻿namespace StoreHub.Dtos.Admin
{
    public class AdminDashboardStatsDto
    {
        public int Products { get; set; }
        public int Orders { get; set; }
        public int Categories { get; set; }
        public int Users { get; set; }
    }
}
