﻿namespace StoreHub.Dtos.Users
{
    public class ResetPasswordDto
    {
        public string NewPassword { get; set; } = "";
    }
}
