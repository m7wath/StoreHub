﻿namespace StoreHub.Dtos.Order
{
    public class OrderDetailDto
    {
    }
}
